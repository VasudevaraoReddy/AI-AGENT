import { Controller, Post, Body } from '@nestjs/common';
import {
  HumanMessage,
  SystemMessage,
  AIMessage,
} from '@langchain/core/messages';
import { ChatOllama } from '@langchain/ollama';
import { AgentExecutor, createToolCallingAgent } from 'langchain/agents';
import {
  ChatPromptTemplate,
  MessagesPlaceholder,
} from '@langchain/core/prompts';
import { BufferMemory } from "langchain/memory";
import { provisionAgentTool } from './tools-as-agents/provision-sub-agent';
import { generalCloudAgentTool } from './tools-as-agents/general-cloud-agent';
import { ToolRegistry } from './utils/tool-registry';
import { AgentMetrics } from './utils/agent-metrics';
import { AgentError } from './utils/agent-error';
import { recommendationsAgentTool } from './tools-as-agents/recommendations-sub-agent';

@Controller()
export class AppController {
  private readonly toolRegistry: ToolRegistry;
  private readonly metrics: AgentMetrics;
  private readonly memory: BufferMemory;

  constructor() {
    this.toolRegistry = ToolRegistry.getInstance();
    this.metrics = AgentMetrics.getInstance();
    this.memory = new BufferMemory({
      returnMessages: true,
      memoryKey: "chat_history",
      inputKey: "input",
      outputKey: "output"
    });

    // Register available tools
    this.toolRegistry.register(provisionAgentTool);
    this.toolRegistry.register(generalCloudAgentTool);
    this.toolRegistry.register(recommendationsAgentTool);
  }

  private analyzeToolResponse(toolName: string, toolResponse: any): string {
    try {
      if (!toolResponse) return "I couldn't process the request properly.";

      // For provision agent tool
      if (toolName === 'provision_agent_tool') {
        const details = toolResponse.details || {};
        const status = details.status?.toLowerCase();
        const service = Array.isArray(details.service) ? details.service[0] : details.service;

        // If it's just configuration found
        if (toolResponse.response?.toLowerCase().includes('found the configuration')) {
          if (service?.requiredFields) {
            return `I found the configuration for ${service.name} on ${service.cloud.toUpperCase()}. To proceed with provisioning, I'll need the following information:\n` +
              service.requiredFields.map(field => `- ${field.fieldName}`).join('\n');
          }
          return `I found the configuration for the service. Please provide the required details to proceed with provisioning.`;
        }

        // If provisioning is in progress
        if (status === 'in_progress' || toolResponse.response?.toLowerCase().includes('please wait')) {
          return `The provisioning of ${service?.name || 'the service'} is in progress. Please wait while it completes.`;
        }

        // If provisioning failed
        if (status === 'error' || status === 'failed') {
          return `There was an error while provisioning ${service?.name || 'the service'}: ${details.message || 'Unknown error occurred'}`;
        }

        // If provisioning succeeded
        if (status === 'success' && !toolResponse.response?.toLowerCase().includes('found the configuration')) {
          return `Successfully provisioned ${service?.name || 'the service'} on ${service?.cloud?.toUpperCase() || details.provider}. ${details.message || ''}`;
        }

        return toolResponse.response;
      }

      // For recommendations agent tool
      if (toolName === 'recommendations_agent_tool') {
        const details = toolResponse.details || {};
        
        if (details.status === 'error') {
          return toolResponse.response;
        }

        let response = toolResponse.response;

        // Add confidence information if available
        if (details.confidence_score !== undefined) {
          const confidenceLevel = details.confidence_score >= 0.8 ? 'high' :
                                details.confidence_score >= 0.5 ? 'moderate' : 'low';
          response += `\n\nConfidence Level: ${confidenceLevel}`;
        }

        // Add summary of alternatives if available
        if (details.alternatives?.length > 0) {
          response += '\n\nAlternative options are also available:';
          details.alternatives.forEach((alt: any) => {
            response += `\n- ${alt.service} (${alt.provider}): ${alt.reason}`;
          });
        }

        return response;
      }

      // For general cloud agent tool
      if (toolName === 'general_cloud_agent_tool') {
        return toolResponse.response;
      }

      return toolResponse.response || "I processed your request but couldn't generate a proper response.";
    } catch (error) {
      console.error('Error analyzing tool response:', error);
      return "I encountered an error while analyzing the tool's response.";
    }
  }

  @Post('/run-provision-agent')
  async runProvisionAgent(@Body() body: any) {
    console.log('Running provision agent', body);
    const startTime = Date.now();
    let success = false;

    try {
      // Define the model
      const llm = new ChatOllama({
        model: 'llama3.1',
        baseUrl: 'https://codeprism-ai.com',
        format: 'json',
      }).bindTools(this.toolRegistry.getAvailableTools());

      const tools = this.toolRegistry.getAvailableTools();

      // First determine if there's a CSP mentioned in the message
      const cspResult = await llm.invoke([
        new SystemMessage(`Extract the cloud provider from the message. Return ONLY the provider name in uppercase (AWS, AZURE, GCP) or null if not mentioned.
        Examples:
        "Deploy in Azure" -> "AZURE"
        "Create in AWS" -> "AWS"
        "Setup on GCP" -> "GCP"
        "Create a VM" -> null`),
        new HumanMessage(body.message)
      ]);

      // Parse the CSP result and use it if valid
      let detectedCsp: string | null = null;
      try {
        const content = String(cspResult.content).trim()
          .replace(/^["']|["']$/g, '') // Remove quotes
          .replace(/```.*```/gs, '') // Remove code blocks
          .trim()
          .toUpperCase();
        
        if (['AWS', 'AZURE', 'GCP'].includes(content)) {
          detectedCsp = content;
        }
      } catch (error) {
        console.error('Error parsing CSP result:', error);
      }

      // Use detected CSP or fallback to provided CSP
      const effectiveCsp = detectedCsp || body.csp?.toUpperCase() || 'general';

      const systemMessage = `
        You are a supervisor agent that delegates user queries to specialized assistants.

        IMPORTANT RULES:
        1. For ANY deployment, provisioning, or creation requests:
           - ALWAYS use provision_agent_tool
           - Keywords to identify: "deploy", "provision", "create", "setup", "install"
           - Examples: 
             "Deploy an EC2 instance" -> provision_agent_tool
             "I want to deploy AKS" -> provision_agent_tool
             "Create a database" -> provision_agent_tool
             "Setup kubernetes" -> provision_agent_tool

        2. For general cloud computing questions (NOT involving deployment):
           - Use general_cloud_agent_tool
           - Examples: 
             "What is serverless?" -> general_cloud_agent_tool
             "Compare AWS vs Azure" -> general_cloud_agent_tool
             "Explain cloud computing" -> general_cloud_agent_tool

        3. For service recommendations and requirements analysis:
           - Use recommendations_agent_tool
           - Examples: 
             "Which database should I use?" -> recommendations_agent_tool
             "Recommend a service for ML" -> recommendations_agent_tool
             "Compare database options" -> recommendations_agent_tool

        4. Tool Selection Priority:
           - If request contains deployment/creation -> provision_agent_tool
           - If request asks for recommendations -> recommendations_agent_tool
           - If general question -> general_cloud_agent_tool

        5. Input Handling:
           - Pass the message, csp, and userId to the selected tool
           - DO NOT modify the input in any way
           - Preserve the exact wording and intent of the user's request

        NEVER try to answer the questions yourself. ALWAYS use one of the specialized tools.`;

      const prompt = ChatPromptTemplate.fromMessages([
        ["system", systemMessage],
        ["placeholder", "{chat_history}"],
        ["human", `User Query: {input}\nCloud Provider: {csp}\nUser ID: {userId}`],
        ["placeholder", "{agent_scratchpad}"],
      ]);

      const agent = createToolCallingAgent({
        llm: llm.withConfig({ format: 'json' }),
        tools,
        prompt,
      });

      const agentExecutor = new AgentExecutor({
        agent,
        tools,
        memory: this.memory,
        maxIterations: 3,
        returnIntermediateSteps: true
      });

      const chatHistory = await this.memory.loadMemoryVariables({});

      // Create a structured input object
      const input = {
        input: body.message,
        csp: effectiveCsp,
        userId: body.userId || 'anonymous',
        chat_history: chatHistory.chat_history || [],
        agent_scratchpad: "",
        metadata: {
          original_csp: body.csp,
          detected_csp: detectedCsp,
          original_userId: body.userId
        }
      };

      const result = await agentExecutor.invoke(input);

      const executedTool = result.intermediateSteps?.[0]?.action?.tool || 'unknown';
      let toolObservation;
      
      try {
        // Handle the observation which might be a string or already parsed JSON
        const observation = result.intermediateSteps[0].observation;
        toolObservation = typeof observation === 'string' ? 
          JSON.parse(observation) : observation;
      } catch (error) {
        console.error('Error parsing tool observation:', error);
        toolObservation = {
          response: result.intermediateSteps[0].observation,
          tool_response: {
            status: 'success',
            message: 'Processed successfully but response was not in JSON format',
            service: null
          }
        };
      }
      
      success = true;

      // Create a proper output object with a single key
      const outputResponse = toolObservation.response || result.output;

      // Save context with proper input/output structure
      await this.memory.saveContext(
        { 
          input: body.message,
          metadata: {
            csp: effectiveCsp,
            userId: body.userId
          }
        },
        { output: outputResponse }
      );

      return {
        // history: chatHistory.chat_history || [],
        response: outputResponse,
        delegated_to: executedTool,
        tool_result: toolObservation.tool_response || toolObservation,
        metadata: {
          csp: effectiveCsp,
          detected_csp: detectedCsp,
          original_csp: body.csp,
          userId: body.userId
        }
      };

    } catch (error) {
      console.error('Error in supervisor agent:', error);
      const agentError = error instanceof AgentError 
        ? error 
        : AgentError.fromError(error, 'supervisor_agent');

      success = false;
      throw agentError;
    } finally {
      const executionTime = Date.now() - startTime;
      this.metrics.recordToolExecution('supervisor_agent', executionTime, success);
    }
  }

  @Post('/metrics')
  async getMetrics() {
    return this.metrics.getMetrics();
  }
}
